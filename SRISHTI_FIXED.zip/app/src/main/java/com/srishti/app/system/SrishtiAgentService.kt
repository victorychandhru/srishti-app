package com.srishti.app.system
import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.srishti.app.MainActivity
import com.srishti.app.SrishtiApplication

class SrishtiAgentService : Service() {
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        startForeground(
            1, NotificationCompat.Builder(this, SrishtiApplication.CH_ID)
                .setContentTitle("SRISHTI Active")
                .setContentText("Your AI Digital Being is running")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi).setOngoing(true).build()
        )
        return START_STICKY
    }
    override fun onBind(i: Intent?): IBinder? = null
}
