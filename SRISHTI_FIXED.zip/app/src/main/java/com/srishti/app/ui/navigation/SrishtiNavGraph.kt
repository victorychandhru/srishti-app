package com.srishti.app.ui.navigation
import androidx.compose.runtime.*
import androidx.navigation.compose.*
import com.srishti.app.ui.screens.*
import com.srishti.app.ui.viewmodel.SrishtiViewModel

@Composable
fun SrishtiNavGraph(vm: SrishtiViewModel) {
    val nav = rememberNavController()
    val screen by vm.screen.collectAsState()
    LaunchedEffect(screen) {
        try {
            if (nav.currentDestination?.route != screen)
                nav.navigate(screen) { launchSingleTop = true }
        } catch (_: Exception) {}
    }
    NavHost(navController = nav, startDestination = screen) {
        composable("create")   { CreateBeingScreen(vm) }
        composable("avatar")   { AvatarScreen(vm) }
        composable("chat")     { ChatScreen(vm) }
        composable("agents")   { AgentPanelScreen(vm) }
        composable("settings") { SettingsScreen(vm) }
    }
}
