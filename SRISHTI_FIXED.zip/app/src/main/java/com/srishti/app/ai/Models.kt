package com.srishti.app.ai
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Parcelize @Serializable
data class DigitalBeing(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String = "SRISHTI",
    val voiceType: VoiceType = VoiceType.NEURAL_FEMALE,
    val personality: PersonalityType = PersonalityType.ASSISTANT,
    val relationship: RelationshipType = RelationshipType.FRIEND,
    val emotionalState: EmotionalState = EmotionalState.NEUTRAL,
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable

@Serializable
enum class PersonalityType(
    val displayName: String, val tamilName: String,
    val description: String, val emoji: String
) {
    GENIUS("Genius","மேதை","Analytical, precise, logical","🧠"),
    FRIENDLY("Friendly","நட்பான","Warm, caring, supportive","😊"),
    ASSISTANT("Assistant","உதவியாளர்","Professional, efficient","💼"),
    CREATIVE("Creative","படைப்பாளி","Imaginative, artistic","🎨"),
    WARRIOR("Warrior","வீரன்","Bold, decisive, fearless","⚔"),
    MYSTIC("Mystic","மர்மவாதி","Spiritual, intuitive","🔮")
}

@Serializable
enum class RelationshipType(
    val displayName: String, val tamilDisplay: String,
    val userAddress: String, val greeting: String, val emoji: String
) {
    FRIEND("Friend","நண்பன்","மச்சி","என்னடா மச்சி! 👊","🤝"),
    BROTHER("Brother","அண்ணன்","தம்பி","என்னடா தம்பி! 💪","👦"),
    MENTOR("Mentor","குரு","சீடா","சொல்லு சீடா 🙏","🧘"),
    PARTNER("Partner","துணை","என் உயிரே","என்னடா! 🌹","💕"),
    SON("Son","மகன்","அப்பா","சொல்லு அப்பா 🙂","👨"),
    DAUGHTER("Daughter","மகள்","அம்மா","சொல்லு அம்மா 🌸","👩"),
    ASSISTANT("Assistant","உதவியாளர்","Sir","Yes Sir! How can I help?","💼"),
    SISTER("Sister","தங்கை","அண்ணா","என்னடா அண்ணா! 😄","👧")
}

@Serializable
enum class VoiceType(
    val displayName: String, val tamilName: String,
    val pitch: Float, val rate: Float, val emoji: String
) {
    NEURAL_FEMALE("Neural Female","பெண் குரல்",1.1f,1.0f,"🎙"),
    NEURAL_MALE("Neural Male","ஆண் குரல்",0.9f,1.0f,"🎤"),
    DEEP_MALE("Deep Male","கம்பீர குரல்",0.7f,0.85f,"🔊"),
    CHILD("Child","குழந்தை குரல்",1.4f,1.1f,"👶"),
    ROBOT("Robot","ரோபோ குரல்",0.6f,0.9f,"🤖")
}

@Serializable
enum class EmotionalState(val emoji: String) {
    NEUTRAL("😐"), HAPPY("😊"), SAD("😢"), THINKING("🤔"),
    EXCITED("🤩"), ANGRY("😤"), SURPRISED("😮"), SLEEPY("😴")
}

@Serializable
enum class AgentType(val displayName: String, val icon: String) {
    MAIN_BRAIN("Main Brain","🧠"), VIDEO_SCRIPT("Video Script","📝"),
    VOICE_SCRIPT("Voice Script","🎙"), CODE_GEN("Code Gen","💻"),
    RESEARCH("Research","🔍"), PLANNER("Planner","📋"), EXECUTOR("Executor","⚡")
}

@Serializable
data class AgentTask(
    val id: String = java.util.UUID.randomUUID().toString(),
    val agentType: AgentType = AgentType.MAIN_BRAIN,
    val instruction: String = "",
    val status: TaskStatus = TaskStatus.PENDING,
    val result: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable enum class TaskStatus { PENDING, RUNNING, COMPLETED, FAILED }

@Serializable
data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: MessageRole = MessageRole.USER,
    val content: String = "",
    val emotion: EmotionalState = EmotionalState.NEUTRAL,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable enum class MessageRole { USER, ASSISTANT }

@Serializable
data class QuantumPath(
    val hypothesis: String = "",
    val probability: Float = 0f,
    val isSelected: Boolean = false
)
