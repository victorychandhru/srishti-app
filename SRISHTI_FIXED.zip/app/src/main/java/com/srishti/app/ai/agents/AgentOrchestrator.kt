package com.srishti.app.ai.agents
import android.content.Context
import com.srishti.app.ai.*
import com.srishti.app.ai.memory.SessionMemoryManager
import com.srishti.app.ai.reasoning.QuantumReasoningEngine
import com.srishti.app.system.SrishtiConfig
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class AgentOrchestrator(
    ctx: Context,
    private val mem: SessionMemoryManager,
    private val scope: CoroutineScope
) {
    private val cfg = SrishtiConfig(ctx)
    private val llm = LLMClient(cfg)
    private val quantum = QuantumReasoningEngine(scope)

    private val _busy = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _busy.asStateFlow()
    private val _emo = MutableStateFlow(EmotionalState.NEUTRAL)
    val currentEmotion: StateFlow<EmotionalState> = _emo.asStateFlow()
    private val _agents = MutableStateFlow<List<AgentTask>>(emptyList())
    val activeAgents: StateFlow<List<AgentTask>> = _agents.asStateFlow()

    private var being: DigitalBeing? = null
    fun setBeing(b: DigitalBeing) { being = b }

    suspend fun process(input: String): String {
        val b = being ?: return "Please create your AI being first!"
        _busy.value = true
        mem.addMessage(ChatMessage(role = MessageRole.USER, content = input))
        return try {
            mem.setQuantumPaths(quantum.reason(input))
            val resp = if (isComplex(input)) multiAgent(input, b) else singleAgent(input, b)
            _emo.value = detectEmotion(resp)
            mem.addMessage(ChatMessage(role = MessageRole.ASSISTANT, content = resp, emotion = _emo.value))
            resp
        } finally {
            _busy.value = false
        }
    }

    private suspend fun singleAgent(input: String, b: DigitalBeing): String {
        val history = mem.getCtx().map { it.role.name.lowercase() to it.content }
        return llm.chat(mem.buildPrompt(b), history + ("user" to input))
    }

    private suspend fun multiAgent(task: String, b: DigitalBeing): String = coroutineScope {
        val master = AgentTask(
            agentType = AgentType.MAIN_BRAIN,
            instruction = task,
            status = TaskStatus.RUNNING
        )
        mem.addTask(master)
        _agents.value = listOf(master)

        val subTasks = quantum.decompose(task)
        val results = subTasks.map { (typeStr, inst) ->
            val type = runCatching { AgentType.valueOf(typeStr) }.getOrDefault(AgentType.EXECUTOR)
            val sub = AgentTask(agentType = type, instruction = inst)
            mem.addTask(sub)
            async(Dispatchers.Default) {
                mem.updateTask(sub.copy(status = TaskStatus.RUNNING))
                val prompt = agentSystemPrompt(type, b)
                val result = llm.chat(prompt, listOf("user" to inst))
                mem.updateTask(sub.copy(status = TaskStatus.COMPLETED, result = result))
                type.displayName to result
            }
        }.awaitAll()

        _agents.value = emptyList()
        val combined = results.joinToString("\n\n") { (n, o) -> "=== $n ===\n$o" }
        llm.chat(
            "You are ${b.name}. Synthesize all agent outputs into one natural, conversational response. Call user '${b.relationship.userAddress}'. Be warm and natural.",
            listOf("user" to "Original request: $task\n\nAgent outputs:\n$combined\n\nSynthesize naturally.")
        )
    }

    private fun agentSystemPrompt(type: AgentType, b: DigitalBeing): String = when (type) {
        AgentType.VIDEO_SCRIPT -> "You are ${b.name}'s Video Script Agent. Write compelling video scripts with scenes, hooks, and CTAs."
        AgentType.VOICE_SCRIPT -> "You are ${b.name}'s Voiceover Agent. Write natural speech with emotion cues and pause markers."
        AgentType.CODE_GEN -> "You are ${b.name}'s Code Agent. Write clean, well-commented, production-ready code."
        AgentType.RESEARCH -> "You are ${b.name}'s Research Agent. Research thoroughly and provide structured key insights."
        AgentType.PLANNER -> "You are ${b.name}'s Planning Agent. Create detailed step-by-step execution plans."
        else -> "You are ${b.name}'s ${type.displayName}. Complete tasks thoroughly and professionally."
    }

    private fun isComplex(t: String) = listOf(
        "video", "code", "research", "create", "make", "build", "analyze",
        "வீடியோ", "கோட்", "உருவாக்கு", "ஆராய்", "செய்"
    ).any { t.contains(it, true) }

    private fun detectEmotion(r: String) = when {
        r.contains(Regex("[!]{2,}|🔥|🚀|🎉|awesome|great")) -> EmotionalState.EXCITED
        r.contains(Regex("sorry|மன்னி|sad|கவலை")) -> EmotionalState.SAD
        r.contains(Regex("✅|good|சரியா|nice")) -> EmotionalState.HAPPY
        r.contains(Regex("🤔|hmm|let me think|யோசி")) -> EmotionalState.THINKING
        else -> EmotionalState.NEUTRAL
    }
}
