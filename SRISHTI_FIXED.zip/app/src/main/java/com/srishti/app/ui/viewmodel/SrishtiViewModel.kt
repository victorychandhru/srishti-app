package com.srishti.app.ui.viewmodel
import android.content.Context
import androidx.lifecycle.*
import com.srishti.app.ai.*
import com.srishti.app.ai.agents.AgentOrchestrator
import com.srishti.app.ai.memory.SessionMemoryManager
import com.srishti.app.ai.voice.VoiceEngine
import com.srishti.app.system.SrishtiConfig
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class SrishtiViewModel(
    private val orc: AgentOrchestrator,
    private val mem: SessionMemoryManager,
    private val cfg: SrishtiConfig,
    ctx: Context
) : ViewModel() {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    val voice = VoiceEngine(ctx)

    private val _being = MutableStateFlow<DigitalBeing?>(loadBeing())
    val being: StateFlow<DigitalBeing?> = _being.asStateFlow()
    private val _screen = MutableStateFlow(if (cfg.isFirst()) "create" else "avatar")
    val screen: StateFlow<String> = _screen.asStateFlow()

    val chat = mem.chatHistory
    val busy = orc.isProcessing
    val emotion = orc.currentEmotion
    val agents = orc.activeAgents
    val paths = mem.quantumPaths
    val isSpeaking = voice.isSpeaking
    val lipSync = voice.lipSync

    private val _input = MutableStateFlow("")
    val input: StateFlow<String> = _input.asStateFlow()

    init { _being.value?.let { voice.init(it.voiceType) } }

    fun createBeing(b: DigitalBeing) {
        _being.value = b
        orc.setBeing(b)
        runCatching { cfg.saveBeing(json.encodeToString(b)) }
        cfg.setDone()
        voice.init(b.voiceType)
        _screen.value = "avatar"
    }

    fun send(text: String) {
        if (text.isBlank()) return
        _input.value = ""
        viewModelScope.launch {
            val resp = orc.process(text)
            if (voice.isReady.value) voice.speak(resp)
        }
    }

    fun setInput(t: String) { _input.value = t }
    fun nav(s: String) { _screen.value = s }
    fun stopVoice() { voice.stop() }
    fun clearChat() { mem.clear() }
    fun getApiKey() = cfg.getApiKey()
    fun setApiKey(k: String) { cfg.setApiKey(k) }
    fun getEndpoint() = cfg.getEndpoint()
    fun setEndpoint(e: String) { cfg.setEndpoint(e) }
    fun resetBeing() { cfg.clear(); _being.value = null; _screen.value = "create" }

    private fun loadBeing(): DigitalBeing? = runCatching {
        cfg.getBeing()?.let {
            json.decodeFromString<DigitalBeing>(it)
        }?.also { orc.setBeing(it) }
    }.getOrNull()

    override fun onCleared() { super.onCleared(); voice.release() }

    class Factory(
        private val orc: AgentOrchestrator,
        private val mem: SessionMemoryManager,
        private val cfg: SrishtiConfig,
        private val ctx: Context
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(c: Class<T>): T =
            SrishtiViewModel(orc, mem, cfg, ctx) as T
    }
}
