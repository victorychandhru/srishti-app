package com.srishti.app
import android.app.*
import android.os.Build
import com.srishti.app.ai.agents.AgentOrchestrator
import com.srishti.app.ai.memory.SessionMemoryManager
import com.srishti.app.system.SrishtiConfig
import kotlinx.coroutines.*

class SrishtiApplication : Application() {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    lateinit var mem: SessionMemoryManager
    lateinit var orc: AgentOrchestrator
    lateinit var cfg: SrishtiConfig

    companion object {
        lateinit var app: SrishtiApplication private set
        const val CH_ID = "srishti_main_channel"
    }

    override fun onCreate() {
        super.onCreate()
        app = this
        cfg = SrishtiConfig(this)
        mem = SessionMemoryManager()
        orc = AgentOrchestrator(this, mem, scope)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(
                    NotificationChannel(CH_ID, "SRISHTI AI", NotificationManager.IMPORTANCE_LOW)
                )
        }
    }
}
