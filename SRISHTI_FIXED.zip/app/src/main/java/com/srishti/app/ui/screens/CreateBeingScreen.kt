package com.srishti.app.ui.screens
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.srishti.app.ai.*
import com.srishti.app.ui.theme.C
import com.srishti.app.ui.viewmodel.SrishtiViewModel

@Composable
fun CreateBeingScreen(vm: SrishtiViewModel) {
    var step by remember { mutableStateOf(0) }
    var name by remember { mutableStateOf("") }
    var per  by remember { mutableStateOf(PersonalityType.ASSISTANT) }
    var rel  by remember { mutableStateOf(RelationshipType.FRIEND) }
    var voc  by remember { mutableStateOf(VoiceType.NEURAL_FEMALE) }
    val inf  = rememberInfiniteTransition(label = "bg")
    val glow by inf.animateFloat(0.3f, 0.8f,
        infiniteRepeatable(tween(3000, easing = EaseInOutSine), RepeatMode.Reverse), label = "g")

    Box(Modifier.fillMaxSize().background(C.Void)) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(C.CGlow.copy(alpha = glow * 0.4f),
                size.minDimension * 0.7f, Offset(size.width * .5f, size.height * .25f))
        }
        Column(
            Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(52.dp))
            Text("⚛", fontSize = 52.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Text("CREATE YOUR", style = MaterialTheme.typography.labelLarge,
                color = C.Cyan, letterSpacing = 4.sp)
            Text("DIGITAL BEING", style = MaterialTheme.typography.displayLarge,
                color = C.T1, fontWeight = FontWeight.Black)
            Text("Quantum AI Companion", style = MaterialTheme.typography.bodyMedium, color = C.T2)
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (0..3).forEach { i ->
                    Box(Modifier.size(if (i == step) 28.dp else 7.dp, 4.dp)
                        .clip(CircleShape)
                        .background(if (i <= step) C.Cyan else C.T3))
                }
            }
            Spacer(Modifier.height(18.dp))
            when (step) {
                0 -> NameStep(name) { name = it }
                1 -> PickerStep(
                    "Personality 🧠",
                    PersonalityType.values().map { Triple(it.emoji, "${it.displayName} · ${it.tamilName}", it.description) },
                    per.ordinal
                ) { per = PersonalityType.values()[it] }
                2 -> PickerStep(
                    "Relationship 💞",
                    RelationshipType.values().map { Triple(it.emoji, "${it.displayName} · ${it.tamilDisplay}", "Calls you: \"${it.userAddress}\"") },
                    rel.ordinal
                ) { rel = RelationshipType.values()[it] }
                3 -> PickerStep(
                    "Voice 🎙",
                    VoiceType.values().map { Triple(it.emoji, it.displayName, it.tamilName) },
                    voc.ordinal
                ) { voc = VoiceType.values()[it] }
            }
            Spacer(Modifier.height(22.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (step > 0) {
                    OutlinedButton(
                        onClick = { step-- }, modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, C.T3),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = C.T2)
                    ) { Text("← Back") }
                }
                Button(
                    onClick = {
                        if (step < 3) step++
                        else vm.createBeing(DigitalBeing(
                            name = name.ifBlank { "SRISHTI" },
                            personality = per, relationship = rel, voiceType = voc
                        ))
                    },
                    modifier = Modifier.weight(1f).height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = C.Cyan, contentColor = C.Void),
                    shape = RoundedCornerShape(12.dp)
                ) { Text(if (step < 3) "Next →" else "✨ Activate!", fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}

@Composable
fun NameStep(name: String, onChange: (String) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Name your AI Being", style = MaterialTheme.typography.headlineMedium, color = C.Cyan)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = name, onValueChange = onChange, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("e.g. AADHI, RIYA, ARJUN...", color = C.T3) },
            label = { Text("Being Name", color = C.Cyan) }, singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = C.Cyan, unfocusedBorderColor = C.T3,
                focusedTextColor = C.T1, unfocusedTextColor = C.T1
            )
        )
        Spacer(Modifier.height(8.dp))
        Text("Leave blank to use 'SRISHTI'", color = C.T3, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun PickerStep(title: String, items: List<Triple<String, String, String>>, selected: Int, onPick: (Int) -> Unit) {
    Column {
        Text(title, style = MaterialTheme.typography.headlineMedium, color = C.Cyan,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        items.forEachIndexed { i, (icon, label, sub) ->
            val sel = i == selected
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onPick(i) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(if (sel) C.Cyan.copy(.12f) else C.Dark),
                border = BorderStroke(if (sel) 1.5.dp else 1.dp, if (sel) C.Cyan else C.T3)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(icon, fontSize = 22.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(label, color = if (sel) C.Cyan else C.T1,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                        Text(sub, color = C.T3, fontSize = 11.sp)
                    }
                    if (sel) Text("✓", color = C.Cyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}
