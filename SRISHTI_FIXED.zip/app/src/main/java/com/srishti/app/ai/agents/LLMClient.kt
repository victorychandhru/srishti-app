package com.srishti.app.ai.agents
import com.srishti.app.system.SrishtiConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class LLMClient(private val cfg: SrishtiConfig) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS).build()

    suspend fun chat(system: String, msgs: List<Pair<String, String>>): String =
        withContext(Dispatchers.IO) {
            val key = cfg.getApiKey()
            if (key.isEmpty()) return@withContext demoResponse(msgs.lastOrNull()?.second ?: "")
            try {
                val ep = cfg.getEndpoint()
                val bodyStr = if (ep.contains("anthropic")) claudeBody(system, msgs, cfg.getModel())
                              else openaiBody(system, msgs, cfg.getModel())
                val request = Request.Builder().url(ep)
                    .post(bodyStr.toRequestBody("application/json".toMediaType()))
                    .apply {
                        if (ep.contains("anthropic")) {
                            header("x-api-key", key)
                            header("anthropic-version", "2023-06-01")
                        } else {
                            header("Authorization", "Bearer $key")
                        }
                    }.build()
                val response = http.newCall(request).execute()
                val body = response.body?.string() ?: return@withContext "No response"
                parseResponse(body, ep)
            } catch (e: Exception) {
                "⚠ Connection error: ${e.message?.take(80)}"
            }
        }

    private fun claudeBody(sys: String, msgs: List<Pair<String, String>>, model: String): String {
        val arr = JSONArray()
        msgs.forEach { (r, c) -> arr.put(JSONObject().put("role", r).put("content", c)) }
        return JSONObject()
            .put("model", model).put("max_tokens", 1024)
            .put("system", sys).put("messages", arr).toString()
    }

    private fun openaiBody(sys: String, msgs: List<Pair<String, String>>, model: String): String {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", sys))
        msgs.forEach { (r, c) -> arr.put(JSONObject().put("role", r).put("content", c)) }
        return JSONObject()
            .put("model", model).put("messages", arr).put("max_tokens", 1024).toString()
    }

    private fun parseResponse(body: String, ep: String): String = try {
        val j = JSONObject(body)
        if (ep.contains("anthropic"))
            j.getJSONArray("content").getJSONObject(0).getString("text")
        else
            j.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
    } catch (e: Exception) { demoResponse("") }

    private fun demoResponse(input: String): String {
        val i = input.lowercase()
        return when {
            i.contains("மச்சி") || i.contains("macchi") ->
                "என்னடா மச்சி! 👊 API key இல்லாம demo mode-ல் இருக்கேன். Settings-ல் Claude API key போடு — anthropic.com-ல் free account எடுக்கலாம்! 🔥"
            i.contains("hello") || i.contains("hi") || i.contains("வணக்கம்") ->
                "வணக்கம்! 🙏 நான் SRISHTI — உன்னோட Quantum AI Digital Being! Settings → API Key போட்டா full power-ல் பேசுவேன்! ✨"
            i.contains("video") || i.contains("வீடியோ") ->
                "🎬 Video create பண்ண ready-ஆ இருக்கேன்! API key போடு — Video Script Agent, Voice Agent எல்லாம் parallel-ஆ run ஆகும்! ⚛"
            i.contains("code") || i.contains("கோட்") ->
                "💻 Code write பண்ண ready! API key போட்டா — Code Gen Agent, Planner Agent automatic-ஆ activate ஆகும்!"
            i.contains("name") || i.contains("பேர்") ->
                "என் பேர் SRISHTI! ⚛ Quantum-Inspired ASI Multi-Agent Digital Being — உன்னோட personal AI companion!"
            i.contains("love") || i.contains("காதல்") ->
                "😊 நான் உன்னோட personal AI! உன்னோட feelings புரியுது. API key போட்டா இன்னும் better-ஆ respond பண்ணுவேன்!"
            i.contains("who") || i.contains("யார்") ->
                "நான் SRISHTI! ⚛ ஒரு Quantum AI — parallel reasoning, multi-agent system, emotional intelligence எல்லாம் என்கிட்ட இருக்கு!"
            else ->
                "🤖 Demo mode! Settings → API Key → anthropic.com-ல் free Claude API key எடுத்து போடு. அப்புறம் நான் உன்னோட true digital companion-ஆ இருப்பேன்! 🚀"
        }
    }
}
