package com.srishti.app.ui.screens
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.srishti.app.ai.*
import com.srishti.app.ui.theme.C
import com.srishti.app.ui.viewmodel.SrishtiViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ChatScreen(vm: SrishtiViewModel) {
    val being    by vm.being.collectAsState()
    val messages by vm.chat.collectAsState()
    val input    by vm.input.collectAsState()
    val busy     by vm.busy.collectAsState()
    val speaking by vm.isSpeaking.collectAsState()
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Box(Modifier.fillMaxSize().background(C.Void)) {
        Column(Modifier.fillMaxSize()) {
            // Top bar
            Box(Modifier.fillMaxWidth().background(C.Dark.copy(alpha = 0.95f))) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp, 10.dp).statusBarsPadding(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { vm.nav("avatar") }) {
                        Icon(Icons.Default.ArrowBack, null, tint = C.Cyan)
                    }
                    Box(
                        Modifier.size(36.dp).clip(CircleShape)
                            .background(Brush.radialGradient(listOf(C.Cyan, C.Purple))),
                        Alignment.Center
                    ) {
                        Text(
                            being?.name?.firstOrNull()?.toString() ?: "S",
                            color = C.Void, fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(being?.name ?: "SRISHTI", color = C.T1, fontWeight = FontWeight.Bold)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(Modifier.size(6.dp).clip(CircleShape)
                                .background(if (speaking) C.Green else if (busy) C.Gold else C.Cyan))
                            Text(
                                if (speaking) "Speaking..." else if (busy) "Thinking..." else "Online · ${being?.relationship?.tamilDisplay}",
                                style = MaterialTheme.typography.bodyMedium, color = C.T2
                            )
                        }
                    }
                    IconButton(onClick = { vm.stopVoice() }) {
                        Icon(
                            if (speaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                            null,
                            tint = if (speaking) C.Red else C.T2,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
            // Messages
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).padding(horizontal = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item { Spacer(Modifier.height(8.dp)) }
                if (messages.isEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("⚛", fontSize = 52.sp)
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    being?.relationship?.greeting ?: "வணக்கம்!",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = C.Cyan, textAlign = TextAlign.Center
                                )
                                Text("Type below to start chatting!",
                                    color = C.T3, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
                items(messages, key = { it.id }) { msg -> ChatBubble(msg, being) }
                if (busy) { item { TypingIndicator(being?.name ?: "S") } }
                item { Spacer(Modifier.height(8.dp)) }
            }
            // Input bar
            Box(Modifier.fillMaxWidth().background(C.Dark.copy(alpha = 0.97f))) {
                Row(
                    Modifier.fillMaxWidth().padding(10.dp).navigationBarsPadding(),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = input, onValueChange = vm::setInput,
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Type a message...", color = C.T3) },
                        maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = C.Cyan, unfocusedBorderColor = C.T3,
                            focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                            focusedContainerColor = C.Neural, unfocusedContainerColor = C.Neural
                        ),
                        shape = RoundedCornerShape(14.dp),
                        trailingIcon = {
                            if (input.isNotEmpty()) IconButton(onClick = { vm.setInput("") }) {
                                Icon(Icons.Default.Clear, null, tint = C.T3,
                                    modifier = Modifier.size(16.dp))
                            }
                        }
                    )
                    FloatingActionButton(
                        onClick = { if (!busy && input.isNotBlank()) vm.send(input) },
                        modifier = Modifier.size(50.dp),
                        containerColor = if (busy) C.T3 else C.Cyan,
                        contentColor = C.Void
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(18.dp),
                            color = C.Cyan, strokeWidth = 2.dp)
                        else Icon(Icons.Default.Send, null)
                    }
                }
            }
        }
    }
}

@Composable
fun ChatBubble(msg: ChatMessage, being: DigitalBeing?) {
    val isUser = msg.role == MessageRole.USER
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Row(Modifier.fillMaxWidth(), if (isUser) Arrangement.End else Arrangement.Start) {
        if (!isUser) {
            Box(
                Modifier.size(26.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(C.Cyan, C.Purple)))
                    .align(Alignment.Bottom),
                Alignment.Center
            ) {
                Text(being?.name?.firstOrNull()?.toString() ?: "S",
                    color = C.Void, fontSize = 11.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(5.dp))
        }
        Column(horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {
            Box(
                Modifier.widthIn(max = 270.dp).clip(
                    RoundedCornerShape(
                        topStart = 16.dp, topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                ).background(
                    if (isUser) Brush.linearGradient(listOf(C.Cyan, C.Blue))
                    else Brush.linearGradient(listOf(C.Neural, C.Dark))
                )
            ) {
                Text(msg.content, Modifier.padding(12.dp, 10.dp),
                    color = if (isUser) C.Void else C.T1,
                    style = MaterialTheme.typography.bodyLarge)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                if (!isUser && msg.emotion != EmotionalState.NEUTRAL)
                    Text(msg.emotion.emoji, fontSize = 9.sp)
                Text(fmt.format(Date(msg.timestamp)),
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 9.sp), color = C.T3)
            }
        }
    }
}

@Composable
fun TypingIndicator(name: String) {
    Row(verticalAlignment = Alignment.Bottom) {
        Box(
            Modifier.size(26.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(C.Cyan, C.Purple))),
            Alignment.Center
        ) {
            Text(name.firstOrNull()?.toString() ?: "S",
                color = C.Void, fontSize = 11.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(5.dp))
        Card(shape = RoundedCornerShape(14.dp, 14.dp, 14.dp, 4.dp),
            colors = CardDefaults.cardColors(C.Neural)) {
            Row(Modifier.padding(14.dp, 12.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                (0..2).forEach { i ->
                    val anim by rememberInfiniteTransition(label = "t$i").animateFloat(
                        0.2f, 1f,
                        infiniteRepeatable(tween(500, delayMillis = i * 170),
                            androidx.compose.animation.core.RepeatMode.Reverse), label = "a")
                    Box(Modifier.size(6.dp).clip(CircleShape).background(C.Cyan)
                        .alpha(anim))
                }
            }
        }
    }
}
