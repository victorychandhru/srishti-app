package com.srishti.app.system
import android.content.Context
import android.content.SharedPreferences

class SrishtiConfig(context: Context) {
    private val p: SharedPreferences =
        context.getSharedPreferences("srishti_prefs", Context.MODE_PRIVATE)
    companion object {
        const val DEFAULT_ENDPOINT = "https://api.anthropic.com/v1/messages"
        const val DEFAULT_MODEL = "claude-opus-4-5"
    }
    fun getEndpoint(): String = p.getString("ep", DEFAULT_ENDPOINT) ?: DEFAULT_ENDPOINT
    fun setEndpoint(v: String) { p.edit().putString("ep", v).apply() }
    fun getApiKey(): String = p.getString("key", "") ?: ""
    fun setApiKey(v: String) { p.edit().putString("key", v).apply() }
    fun getModel(): String = p.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
    fun isFirst(): Boolean = p.getBoolean("first", true)
    fun setDone() { p.edit().putBoolean("first", false).apply() }
    fun saveBeing(json: String) { p.edit().putString("being", json).apply() }
    fun getBeing(): String? = p.getString("being", null)
    fun clear() { p.edit().clear().apply() }
}
