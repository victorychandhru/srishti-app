package com.srishti.app.ui.screens
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.srishti.app.ai.*
import com.srishti.app.ui.theme.C
import com.srishti.app.ui.viewmodel.SrishtiViewModel

@Composable
fun AgentPanelScreen(vm: SrishtiViewModel) {
    val agents by vm.agents.collectAsState()
    val paths  by vm.paths.collectAsState()
    val msgs   by vm.chat.collectAsState()
    val being  by vm.being.collectAsState()
    val busy   by vm.busy.collectAsState()
    var tab    by remember { mutableStateOf(0) }

    Box(Modifier.fillMaxSize().background(C.Void)) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxWidth().background(C.Dark)) {
                Row(Modifier.fillMaxWidth().padding(14.dp).statusBarsPadding(),
                    verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { vm.nav("avatar") }) {
                        Icon(Icons.Default.ArrowBack, null, tint = C.Cyan)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("AGENT PANEL", style = MaterialTheme.typography.labelLarge,
                            color = C.Cyan, letterSpacing = 3.sp)
                        Text("Quantum Multi-Agent System", color = C.T3,
                            style = MaterialTheme.typography.bodyMedium)
                    }
                    if (busy) CircularProgressIndicator(Modifier.size(18.dp),
                        color = C.Cyan, strokeWidth = 2.dp)
                }
            }
            TabRow(selectedTabIndex = tab, containerColor = C.Dark, contentColor = C.Cyan) {
                listOf("🤖 Agents", "⚛ Quantum", "💾 Memory").forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }) {
                        Text(t, Modifier.padding(12.dp), style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
            when (tab) {
                0 -> AgentsTabContent(agents, being)
                1 -> QuantumTabContent(paths)
                else -> MemoryTabContent(msgs)
            }
        }
    }
}

@Composable
fun AgentsTabContent(agents: List<AgentTask>, being: DigitalBeing?) {
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(C.Neural),
                border = BorderStroke(1.dp, C.CGlow)) {
                Column(Modifier.padding(14.dp)) {
                    Text("⚛ Quantum Agent Network", color = C.Cyan,
                        style = MaterialTheme.typography.titleLarge)
                    Text("${AgentType.values().size} agent types · Parallel processing enabled",
                        color = C.T2, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        if (agents.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().padding(28.dp), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🌙", fontSize = 44.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Agents Idle", color = C.T2,
                            style = MaterialTheme.typography.headlineMedium)
                        Text(
                            "Ask ${being?.name ?: "SRISHTI"} to create a video, write code, or do research to activate parallel agents",
                            color = C.T3, textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        items(agents) { task -> AgentTaskCard(task) }
        item {
            Spacer(Modifier.height(6.dp))
            Text("ALL AVAILABLE AGENTS", style = MaterialTheme.typography.labelLarge, color = C.T3)
        }
        items(AgentType.values().toList()) { type ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(type.icon, fontSize = 18.sp)
                Spacer(Modifier.width(10.dp))
                Text(type.displayName, color = C.T2, modifier = Modifier.weight(1f))
                Box(Modifier.clip(RoundedCornerShape(4.dp)).background(C.Neural).padding(4.dp, 2.dp)) {
                    Text("Ready", color = C.Green,
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 9.sp))
                }
            }
        }
    }
}

@Composable
fun AgentTaskCard(task: AgentTask) {
    val isRunning = task.status == TaskStatus.RUNNING
    val rot by rememberInfiniteTransition(label = "r${task.id}").animateFloat(
        0f, 360f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "ro")
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(C.Neural),
        border = BorderStroke(1.dp, when (task.status) {
            TaskStatus.RUNNING   -> C.Gold
            TaskStatus.COMPLETED -> C.Green
            TaskStatus.FAILED    -> C.Red
            else                 -> C.T3
        })
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(task.agentType.icon, fontSize = 22.sp,
                modifier = if (isRunning) Modifier.rotate(rot) else Modifier)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(task.agentType.displayName, color = C.T1)
                Text(task.instruction.take(60) + if (task.instruction.length > 60) "…" else "",
                    color = C.T2, style = MaterialTheme.typography.bodyMedium)
                task.result?.let {
                    Text(it.take(80) + "…", color = C.Green,
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp))
                }
            }
            val (sc, sl) = when (task.status) {
                TaskStatus.PENDING   -> C.T3 to "WAIT"
                TaskStatus.RUNNING   -> C.Gold to "RUN"
                TaskStatus.COMPLETED -> C.Green to "DONE"
                TaskStatus.FAILED    -> C.Red to "FAIL"
            }
            Box(Modifier.clip(RoundedCornerShape(6.dp))
                .background(sc.copy(alpha = 0.1f))
                .border(1.dp, sc, RoundedCornerShape(6.dp))
                .padding(5.dp, 3.dp)) {
                Text(sl, color = sc,
                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 9.sp))
            }
        }
    }
}

@Composable
fun QuantumTabContent(paths: List<QuantumPath>) {
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(C.Neural),
                border = BorderStroke(1.dp, C.PGlow)) {
                Column(Modifier.padding(14.dp)) {
                    Text("⚛ Quantum Reasoning Engine", color = C.Purple,
                        style = MaterialTheme.typography.titleLarge)
                    Text("Parallel decision paths · Probability collapse · Wave function",
                        color = C.T2, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        if (paths.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().padding(28.dp), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🔮", fontSize = 44.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Send a message to activate quantum reasoning paths",
                            color = C.T3, textAlign = TextAlign.Center)
                    }
                }
            }
        }
        items(paths) { p ->
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(12.dp),
                CardDefaults.cardColors(if (p.isSelected) C.Purple.copy(alpha = 0.1f) else C.Dark),
                BorderStroke(if (p.isSelected) 2.dp else 1.dp, if (p.isSelected) C.Purple else C.T3)) {
                Column(Modifier.padding(14.dp)) {
                    Text((if (p.isSelected) "⭐ " else "") + p.hypothesis,
                        color = if (p.isSelected) C.Purple else C.T1)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { p.probability },
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                        color = if (p.isSelected) C.Purple else C.Cyan,
                        trackColor = C.Neural
                    )
                    Row(Modifier.fillMaxWidth(), Arrangement.End) {
                        Text("${(p.probability * 100).toInt()}%",
                            color = if (p.isSelected) C.Purple else C.Cyan,
                            style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

@Composable
fun MemoryTabContent(msgs: List<ChatMessage>) {
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item {
            Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(C.Neural),
                border = BorderStroke(1.dp, C.Green.copy(alpha = 0.3f))) {
                Text("💾 Session Memory · ${msgs.size} messages · Volatile (clears on app close)",
                    Modifier.padding(14.dp), color = C.T2,
                    style = MaterialTheme.typography.bodyMedium)
            }
        }
        items(msgs.reversed()) { m ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                Text(if (m.role == MessageRole.USER) "👤" else "🤖", fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    m.content.take(80) + if (m.content.length > 80) "…" else "",
                    color = if (m.role == MessageRole.USER) C.T1 else C.Cyan,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
