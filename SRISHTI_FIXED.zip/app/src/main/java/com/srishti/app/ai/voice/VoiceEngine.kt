package com.srishti.app.ai.voice
import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.srishti.app.ai.VoiceType
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.Locale

class VoiceEngine(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    private val _speaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _speaking.asStateFlow()
    private val _lip = MutableStateFlow(0f)
    val lipSync: StateFlow<Float> = _lip.asStateFlow()
    private val _ready = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _ready.asStateFlow()
    private var lipJob: Job? = null

    fun init(v: VoiceType, onReady: () -> Unit = {}) {
        tts?.shutdown()
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("ta", "IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.ENGLISH)
                }
                tts?.setPitch(v.pitch)
                tts?.setSpeechRate(v.rate)
                _ready.value = true
                onReady()
            }
        }
    }

    fun speak(text: String) {
        if (!_ready.value) return
        val clean = text.replace(Regex("[*#`_]"), "").take(400)
        _speaking.value = true
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { startLip() }
            override fun onDone(id: String?) { _speaking.value = false; stopLip() }
            override fun onError(id: String?) { _speaking.value = false; stopLip() }
        })
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "srishti_${System.currentTimeMillis()}")
    }

    fun stop() {
        tts?.stop()
        _speaking.value = false
        stopLip()
    }

    private fun startLip() {
        lipJob?.cancel()
        lipJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive) {
                _lip.value = 0.2f + kotlin.random.Random.nextFloat() * 0.8f
                delay(80L)
            }
        }
    }

    private fun stopLip() {
        lipJob?.cancel()
        _lip.value = 0f
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        lipJob?.cancel()
    }
}
