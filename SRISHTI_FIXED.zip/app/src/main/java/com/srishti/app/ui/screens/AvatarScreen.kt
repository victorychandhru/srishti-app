package com.srishti.app.ui.screens
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.srishti.app.ai.EmotionalState
import com.srishti.app.ui.theme.C
import com.srishti.app.ui.viewmodel.SrishtiViewModel

@Composable
fun AvatarScreen(vm: SrishtiViewModel) {
    val being    by vm.being.collectAsState()
    val emotion  by vm.emotion.collectAsState()
    val busy     by vm.busy.collectAsState()
    val speaking by vm.isSpeaking.collectAsState()
    val lip      by vm.lipSync.collectAsState()
    val inf = rememberInfiniteTransition(label = "bg")
    val pulse by inf.animateFloat(0.3f, 0.7f,
        infiniteRepeatable(tween(3000, easing = EaseInOutSine), RepeatMode.Reverse), label = "p")

    Box(Modifier.fillMaxSize().background(C.Void)) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(C.CGlow.copy(alpha = pulse * 0.55f),
                size.minDimension * 0.65f, Offset(size.width * .5f, size.height * .36f))
            drawCircle(C.PGlow.copy(alpha = (1f - pulse) * 0.35f),
                size.minDimension * 0.4f, Offset(size.width * .5f, size.height * .36f))
        }
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(50.dp))
            // Top bar
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("SRISHTI", style = MaterialTheme.typography.labelLarge,
                    color = C.Cyan, letterSpacing = 4.sp)
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (busy || speaking) {
                        val da by rememberInfiniteTransition(label = "d").animateFloat(
                            0.3f, 1f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = "da")
                        Box(Modifier.size(8.dp).clip(CircleShape)
                            .background(if (speaking) C.Green else C.Gold).alpha(da))
                        Text(if (speaking) "Speaking" else "Thinking...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (speaking) C.Green else C.Gold)
                    }
                    IconButton(onClick = { vm.nav("settings") }) {
                        Icon(Icons.Default.Settings, null, tint = C.T2,
                            modifier = Modifier.size(20.dp))
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            // Animated Avatar Face
            AvatarFaceComposable(emotion, speaking, busy, lip)
            Spacer(Modifier.height(12.dp))
            Text(being?.name ?: "SRISHTI",
                style = MaterialTheme.typography.headlineLarge,
                color = C.T1, fontWeight = FontWeight.Black)
            Text("${being?.personality?.emoji} ${being?.personality?.displayName}  ·  ${being?.relationship?.emoji} ${being?.relationship?.displayName}",
                color = C.T2, style = MaterialTheme.typography.bodyMedium)
            Text("${emotion.emoji}  ${emotion.name.lowercase().replaceFirstChar { it.uppercase() }}",
                color = C.Cyan, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(18.dp))
            Card(Modifier.padding(horizontal = 26.dp), RoundedCornerShape(16.dp),
                CardDefaults.cardColors(C.Glass), BorderStroke(1.dp, C.GlassB)) {
                Text(being?.relationship?.greeting ?: "வணக்கம்! 🙏",
                    Modifier.padding(18.dp),
                    style = MaterialTheme.typography.bodyLarge,
                    color = C.T1, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.weight(1f))
            // Bottom nav
            Card(Modifier.fillMaxWidth().padding(14.dp), RoundedCornerShape(20.dp),
                CardDefaults.cardColors(C.Glass), BorderStroke(1.dp, C.GlassB)) {
                Row(Modifier.fillMaxWidth().padding(8.dp), Arrangement.SpaceEvenly) {
                    NavBtn("💬", "Chat", C.Cyan) { vm.nav("chat") }
                    if (speaking) NavBtn("🔇", "Stop", C.Red) { vm.stopVoice() }
                    NavBtn("🤖", "Agents", C.Purple) { vm.nav("agents") }
                    NavBtn("⚙", "Settings", C.T2) { vm.nav("settings") }
                }
            }
        }
    }
}

@Composable
fun AvatarFaceComposable(emotion: EmotionalState, speaking: Boolean, busy: Boolean, lip: Float) {
    val inf = rememberInfiniteTransition(label = "face")
    val ringRot by inf.animateFloat(0f, 360f,
        infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "ring")
    val scalePulse by inf.animateFloat(.93f, 1.04f,
        infiniteRepeatable(tween(2000, easing = EaseInOutSine), RepeatMode.Reverse), label = "scale")
    val blinkVal by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3000)), label = "blink")
    val isBlink = (blinkVal % 1f) > 0.93f

    Box(Modifier.size(200.dp), Alignment.Center) {
        Canvas(Modifier.matchParentSize().rotate(ringRot)) {
            drawArc(
                Brush.sweepGradient(listOf(C.Cyan, C.Purple, Color.Transparent, C.Cyan)),
                0f, 270f, false, style = Stroke(2.5f)
            )
        }
        Canvas(Modifier.matchParentSize().scale(scalePulse)) {
            drawCircle(C.CGlow.copy(alpha = 0.35f), size.minDimension / 2f - 10f)
        }
        Box(
            Modifier.size(158.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(C.Neural, C.Dark)))
                .border(2.dp, Brush.sweepGradient(listOf(C.Cyan, C.Purple, C.Cyan)), CircleShape),
            Alignment.Center
        ) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    EyeShape(emotion, isBlink)
                    EyeShape(emotion, isBlink)
                }
                Spacer(Modifier.height(14.dp))
                MouthShape(emotion, speaking, lip)
            }
            if (busy) {
                val spinVal by rememberInfiniteTransition(label = "spin").animateFloat(
                    0f, 360f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "s")
                Canvas(Modifier.matchParentSize().rotate(spinVal)) {
                    drawArc(C.Cyan.copy(alpha = 0.25f), 0f, 100f, false, style = Stroke(3f))
                }
            }
        }
        if (emotion != EmotionalState.NEUTRAL) {
            Box(Modifier.align(Alignment.TopEnd).offset((-6).dp, 14.dp)
                .size(26.dp).clip(CircleShape).background(C.Neural), Alignment.Center) {
                Text(emotion.emoji, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun EyeShape(emotion: EmotionalState, blink: Boolean) {
    val h = if (blink) 2.dp else when (emotion) {
        EmotionalState.HAPPY -> 6.dp
        EmotionalState.SLEEPY -> 3.dp
        EmotionalState.ANGRY -> 5.dp
        else -> 10.dp
    }
    Box(Modifier.size(13.dp, h).clip(RoundedCornerShape(50)).background(C.Cyan))
}

@Composable
fun MouthShape(emotion: EmotionalState, speaking: Boolean, lip: Float) {
    val w = if (speaking) (18 + lip * 10).dp else 22.dp
    val h = if (speaking) (5 + lip * 10).dp else when (emotion) {
        EmotionalState.HAPPY, EmotionalState.EXCITED -> 5.dp
        EmotionalState.SAD -> 4.dp
        else -> 3.dp
    }
    Box(Modifier.size(w, h).clip(RoundedCornerShape(50))
        .background(if (speaking) C.Green else C.Cyan))
}

@Composable
fun NavBtn(icon: String, label: String, color: Color, onClick: () -> Unit) {
    Column(
        Modifier.clickable(onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 22.sp)
        Text(label, style = MaterialTheme.typography.labelLarge.copy(fontSize = 10.sp), color = color)
    }
}
