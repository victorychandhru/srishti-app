package com.srishti.app.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object C {
    val Void    = Color(0xFF000308)
    val Dark    = Color(0xFF050A12)
    val Neural  = Color(0xFF0A1628)
    val Cyan    = Color(0xFF00D4FF)
    val Blue    = Color(0xFF0066FF)
    val Purple  = Color(0xFF8B00FF)
    val Green   = Color(0xFF00FF88)
    val Gold    = Color(0xFFFFD700)
    val Red     = Color(0xFFFF2255)
    val Glow    = Color(0xFF00FFDD)
    val T1      = Color(0xFFE8F4FF)
    val T2      = Color(0xFF7AA5CC)
    val T3      = Color(0xFF3A5470)
    val Glass   = Color(0x14FFFFFF)
    val GlassB  = Color(0x30FFFFFF)
    val CGlow   = Color(0x4000D4FF)
    val PGlow   = Color(0x408B00FF)
}

@Composable
fun SrishtiTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = C.Cyan, onPrimary = C.Void,
        primaryContainer = C.Neural,
        secondary = C.Purple, onSecondary = C.T1,
        background = C.Void, onBackground = C.T1,
        surface = C.Dark, onSurface = C.T1,
        surfaceVariant = C.Neural, outline = C.T3,
        error = C.Red, tertiary = C.Green, onTertiary = C.Void
    ),
    typography = Typography(
        displayLarge   = TextStyle(fontWeight = FontWeight.Black,    fontSize = 30.sp, letterSpacing = 2.sp),
        headlineLarge  = TextStyle(fontWeight = FontWeight.Bold,     fontSize = 22.sp),
        headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = C.Cyan),
        titleLarge     = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
        bodyLarge      = TextStyle(fontWeight = FontWeight.Normal,   fontSize = 15.sp),
        bodyMedium     = TextStyle(fontWeight = FontWeight.Normal,   fontSize = 13.sp, color = C.T2),
        labelLarge     = TextStyle(fontWeight = FontWeight.Medium,   fontSize = 11.sp, letterSpacing = 1.sp, color = C.Cyan)
    ),
    content = content
)
