package com.srishti.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.view.WindowCompat
import com.srishti.app.ui.navigation.SrishtiNavGraph
import com.srishti.app.ui.theme.SrishtiTheme
import com.srishti.app.ui.viewmodel.SrishtiViewModel

class MainActivity : ComponentActivity() {
    private val vm: SrishtiViewModel by viewModels {
        val a = application as SrishtiApplication
        SrishtiViewModel.Factory(a.orc, a.mem, a.cfg, applicationContext)
    }
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            SrishtiTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF000308)
                ) {
                    SrishtiNavGraph(vm)
                }
            }
        }
    }
}
