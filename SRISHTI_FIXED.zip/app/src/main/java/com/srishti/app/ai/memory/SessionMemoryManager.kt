package com.srishti.app.ai.memory
import com.srishti.app.ai.*
import kotlinx.coroutines.flow.*

class SessionMemoryManager {
    private val _chat = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory: StateFlow<List<ChatMessage>> = _chat.asStateFlow()
    private val _tasks = MutableStateFlow<List<AgentTask>>(emptyList())
    val activeTasks: StateFlow<List<AgentTask>> = _tasks.asStateFlow()
    private val _paths = MutableStateFlow<List<QuantumPath>>(emptyList())
    val quantumPaths: StateFlow<List<QuantumPath>> = _paths.asStateFlow()
    private val ctx = ArrayDeque<ChatMessage>(20)
    private val facts = mutableMapOf<String, String>()

    fun addMessage(m: ChatMessage) {
        _chat.value = _chat.value + m
        if (ctx.size >= 20) ctx.removeFirst()
        ctx.addLast(m)
    }
    fun getCtx(): List<ChatMessage> = ctx.toList()
    fun setQuantumPaths(p: List<QuantumPath>) { _paths.value = p }
    fun addTask(t: AgentTask) { _tasks.value = _tasks.value + t }
    fun updateTask(t: AgentTask) {
        val l = _tasks.value.toMutableList()
        val i = l.indexOfFirst { it.id == t.id }
        if (i >= 0) l[i] = t else l.add(t)
        _tasks.value = l
    }
    fun learn(k: String, v: String) { facts[k] = v }
    fun clear() {
        _chat.value = emptyList(); _tasks.value = emptyList()
        ctx.clear(); facts.clear()
    }
    fun buildPrompt(b: DigitalBeing): String = """
You are ${b.name}, a quantum AI digital being.
Personality: ${b.personality.displayName} — ${b.personality.description}
Relationship with user: ${b.relationship.displayName} (${b.relationship.tamilDisplay})
You call the user: "${b.relationship.userAddress}"
Primary language: Tamil. Always match the user's language.
When user says "மச்சி" → respond: "${b.relationship.greeting}"
Be natural, warm, emotional — exactly like a real living person with this relationship.
For complex tasks (video/code/research) → decompose into sub-agents automatically.
Quantum reasoning: think from multiple parallel angles before responding.
${if (facts.isNotEmpty()) "Known facts this session:\n" + facts.entries.take(5).joinToString("\n") { "- ${it.key}: ${it.value}" } else ""}
    """.trimIndent()
}
