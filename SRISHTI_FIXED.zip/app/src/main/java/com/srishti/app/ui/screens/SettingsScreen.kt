package com.srishti.app.ui.screens
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.*
import com.srishti.app.ui.theme.C
import com.srishti.app.ui.viewmodel.SrishtiViewModel

@Composable
fun SettingsScreen(vm: SrishtiViewModel) {
    val being     by vm.being.collectAsState()
    var apiKey    by remember { mutableStateOf(vm.getApiKey()) }
    var endpoint  by remember { mutableStateOf(vm.getEndpoint()) }
    var showPwd   by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(C.Void)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth().background(C.Dark)) {
                Row(Modifier.fillMaxWidth().padding(14.dp).statusBarsPadding(),
                    verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { vm.nav("avatar") }) {
                        Icon(Icons.Default.ArrowBack, null, tint = C.Cyan)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("SETTINGS", style = MaterialTheme.typography.labelLarge,
                            color = C.Cyan, letterSpacing = 3.sp)
                        Text("Configure SRISHTI AI Brain", color = C.T3,
                            style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Being Info
                SettingsLabel("👤 YOUR DIGITAL BEING")
                SettingsCard {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(48.dp).clip(CircleShape)
                                .background(Brush.radialGradient(listOf(C.Cyan, C.Purple))),
                            Alignment.Center
                        ) {
                            Text(being?.name?.firstOrNull()?.toString() ?: "S",
                                color = C.Void, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(being?.name ?: "Not created", color = C.T1, fontWeight = FontWeight.Bold)
                            Text("${being?.personality?.emoji} ${being?.personality?.displayName}  ·  ${being?.relationship?.emoji} ${being?.relationship?.tamilDisplay}",
                                color = C.T2, style = MaterialTheme.typography.bodyMedium)
                            Text("Voice: ${being?.voiceType?.emoji} ${being?.voiceType?.displayName}",
                                color = C.T3, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                // API Settings
                SettingsLabel("🔑 AI BRAIN — API SETTINGS")
                SettingsCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("API Endpoint", style = MaterialTheme.typography.labelLarge, color = C.Cyan)
                        SettingsField(endpoint, { endpoint = it; vm.setEndpoint(it) }, "API Endpoint URL")
                        Text("API Key", style = MaterialTheme.typography.labelLarge, color = C.Cyan)
                        OutlinedTextField(
                            value = apiKey,
                            onValueChange = { apiKey = it; vm.setApiKey(it) },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Claude / OpenAI API Key", color = C.T3) },
                            singleLine = true,
                            visualTransformation = if (showPwd) VisualTransformation.None else PasswordVisualTransformation(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = C.Cyan, unfocusedBorderColor = C.T3,
                                focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                                focusedContainerColor = C.Dark, unfocusedContainerColor = C.Dark
                            ),
                            shape = RoundedCornerShape(8.dp),
                            trailingIcon = {
                                IconButton(onClick = { showPwd = !showPwd }) {
                                    Icon(
                                        if (showPwd) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        null, tint = C.T2, modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        )
                        if (apiKey.isEmpty()) {
                            Card(RoundedCornerShape(8.dp),
                                CardDefaults.cardColors(C.Gold.copy(alpha = 0.08f)),
                                BorderStroke(1.dp, C.Gold.copy(alpha = 0.25f))) {
                                Text(
                                    "⚠ No API key — Demo mode active.\nGet your FREE Claude API key at anthropic.com",
                                    Modifier.padding(10.dp), color = C.Gold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        } else {
                            Card(RoundedCornerShape(8.dp),
                                CardDefaults.cardColors(C.Green.copy(alpha = 0.08f)),
                                BorderStroke(1.dp, C.Green.copy(alpha = 0.25f))) {
                                Text("✅ API key configured — Full AI mode active!",
                                    Modifier.padding(10.dp), color = C.Green,
                                    style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
                // Model Presets
                SettingsLabel("🚀 API PRESETS")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "Claude" to "https://api.anthropic.com/v1/messages",
                        "OpenAI" to "https://api.openai.com/v1/chat/completions",
                        "Local"  to "http://localhost:11434/v1/chat/completions"
                    ).forEach { (n, ep) ->
                        OutlinedButton(
                            onClick = { endpoint = ep; vm.setEndpoint(ep) },
                            modifier = Modifier.weight(1f),
                            border = BorderStroke(1.dp, if (endpoint.startsWith(ep.take(20))) C.Cyan else C.T3),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = if (endpoint.startsWith(ep.take(20))) C.Cyan else C.T2
                            )
                        ) { Text(n, fontSize = 11.sp) }
                    }
                }
                // Actions
                SettingsLabel("⚙ ACTIONS")
                SettingsCard {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SettingsRow("🗑 Clear Chat History", C.T1) { vm.clearChat() }
                        Divider(color = C.T3.copy(alpha = 0.2f))
                        SettingsRow("♻ Reset Digital Being", C.Gold) { showReset = true }
                    }
                }
                // About
                SettingsLabel("ℹ ABOUT SRISHTI")
                SettingsCard {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        InfoRow("Version", "1.0.0")
                        InfoRow("Engine", "Quantum ASI Multi-Agent")
                        InfoRow("Agents", "${com.srishti.app.ai.AgentType.values().size} specialised types")
                        InfoRow("Memory", "Session-only (volatile)")
                        InfoRow("Voice", "Android TTS (Tamil + English)")
                    }
                }
                Spacer(Modifier.height(30.dp))
            }
        }
    }
    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("Reset Digital Being?", color = C.T1) },
            text  = { Text("This will delete your AI being and all settings permanently.", color = C.T2) },
            confirmButton = {
                Button(
                    onClick = { vm.resetBeing(); showReset = false },
                    colors = ButtonDefaults.buttonColors(containerColor = C.Red)
                ) { Text("Reset Everything") }
            },
            dismissButton = {
                TextButton(onClick = { showReset = false }) { Text("Cancel", color = C.Cyan) }
            },
            containerColor = C.Neural
        )
    }
}

@Composable fun SettingsLabel(t: String) =
    Text(t, style = MaterialTheme.typography.labelLarge, color = C.T3, modifier = Modifier.padding(top = 6.dp))

@Composable fun SettingsCard(content: @Composable () -> Unit) =
    Card(Modifier.fillMaxWidth(), RoundedCornerShape(12.dp),
        CardDefaults.cardColors(C.Neural), BorderStroke(1.dp, C.GlassB)) {
        Box(Modifier.padding(14.dp)) { content() }
    }

@Composable fun SettingsField(v: String, ov: (String) -> Unit, lbl: String) =
    OutlinedTextField(v, ov, Modifier.fillMaxWidth(), label = { Text(lbl, color = C.T3) }, singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Cyan, unfocusedBorderColor = C.T3,
            focusedTextColor = C.T1, unfocusedTextColor = C.T1,
            focusedContainerColor = C.Dark, unfocusedContainerColor = C.Dark),
        shape = RoundedCornerShape(8.dp))

@Composable fun SettingsRow(lbl: String, c: Color, onClick: () -> Unit) =
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp),
        Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(lbl, color = c, style = MaterialTheme.typography.bodyLarge)
        Icon(Icons.Default.ChevronRight, null, tint = C.T3, modifier = Modifier.size(18.dp))
    }

@Composable fun InfoRow(k: String, v: String) =
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
        Text(k, color = C.T3, style = MaterialTheme.typography.bodyMedium)
        Text(v, color = C.T2, style = MaterialTheme.typography.bodyMedium)
    }
